public class Percolation {
  private final WeightedQuickUnionUF uf;
  private final int topVE;
  private final int botVE;
  private final int dimension;
  private final boolean[] opens;

  /**
   * create N-by-N grid, with all sites blocked
   */
  public Percolation(int N) {
    dimension = N;
    int count = N * N;
    topVE = count;
    botVE = count + 1;
    opens = new boolean[count];
    for (int i = 0; i < count; i++) {
      opens[i] = false;
    }
    uf = new WeightedQuickUnionUF(count + 2);
    int lastRow = topVE - dimension;
    for (int i = 0; i < dimension; i++) {
      uf.union(topVE, i);
      uf.union(botVE, lastRow + i);
    }
  }

  private void checkInput(int i, int j) {
    if (i < 1 || i > dimension || j < 1 || j > dimension) {
      throw new IllegalArgumentException();
    }
  }

  /**
   * open site (row i, column j) if it is not already
   */
  public void open(int i, int j) {
    checkInput(i, j);
    int curr = (i - 1) * dimension + j - 1;
    if (!opens[curr]) {
      opens[curr] = true;
      if (i > 1) {
        if (isOpen(i - 1, j)) {
          uf.union(curr - dimension, curr);
        }
      }
      if (j > 1) {
        if (isOpen(i, j - 1)) {
          uf.union(curr - 1, curr);
        }
      }
      if (j < dimension) {
        if (isOpen(i, j + 1)) {
          uf.union(curr + 1, curr);
        }
      }
      if (i < dimension) {
        if (isOpen(i + 1, j)) {
          uf.union(curr + dimension, curr);
        }
      }
    }
  }

  /**
   * is site (row i, column j) open?
   * 
   * @param i
   * @param j
   * @return
   */
  public boolean isOpen(int i, int j) {
    checkInput(i, j);
    return opens[(i - 1) * dimension + j - 1];
  }

  /**
   * is site (row i, column j) full?
   * 
   * @param i
   * @param j
   * @return
   */
  public boolean isFull(int i, int j) {
    return !isOpen(i, j);
  }

  /**
   * does the system percolate?
   * 
   * @return
   */
  public boolean percolates() {
    return uf.connected(topVE, botVE);
  }
}
